import os
import re

p1 = r"C:\Users\maat\.gemini\antigravity\brain\dda702fe-3efa-4434-83d5-3111cadb22cf\.system_generated\steps\3149\content.md"

if os.path.exists(p1):
    with open(p1, "r", encoding="utf-8") as f:
        html = f.read()

    # Find author section in Zenodo HTML
    # Zenodo typically has: <section id="record-creators"> or class="creatibutor-name"
    for m in re.finditer(r'<(?:span|div|a|li)[^>]*class="[^"]*(?:creatibutor|author|affiliation)[^"]*"[^>]*>(.*?)</(?:span|div|a|li)>', html, re.DOTALL):
        text = re.sub(r'<[^>]+>', ' ', m.group(1)).strip()
        if text:
            print("Found:", text)

    # Also search for "Volkan" or "Dağlı" or "ITOUCH" in nearby lines
    lines = html.splitlines()
    for i, l in enumerate(lines):
        if any(k in l for k in ["Volkan", "Dağlı", "Dagli", "ITOUCH", "Çukurova", "Anadolu", "Department"]):
            print(f"L{i}: {l.strip()[:180]}")
